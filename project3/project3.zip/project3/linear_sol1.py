# Since the user requested a visualization for the restaurant problem with x1 fixed at 0,
# let's create a heatmap showing a feasible region for x2 and x3 on a 2D plot.

import numpy as np
import matplotlib.pyplot as plt

# Given constants for constraints
ingredient_x_max = 100
ingredient_y_max = 72
kitchen_time_max = 80

# Given coefficients for constraints
coeff_x2_x = 2
coeff_x3_x = 1
coeff_x2_y = 3
coeff_x3_y = 2
coeff_x2_kt = 4
coeff_x3_kt = 1

# Create a grid of x2 and x3 values
x2 = np.linspace(0, ingredient_x_max / coeff_x2_x, 400)
x3 = np.linspace(0, kitchen_time_max / coeff_x3_kt, 400)
x2_grid, x3_grid = np.meshgrid(x2, x3)

# Initialize a zeros matrix for feasibility; it will be filled with NaNs for infeasible points
feasibility = np.zeros(x2_grid.shape)

# Apply the constraints to each point in the grid
for i in range(x2_grid.shape[0]):
    for j in range(x2_grid.shape[1]):
        if (coeff_x2_x * x2_grid[i, j] + coeff_x3_x * x3_grid[i, j] <= ingredient_x_max and
            coeff_x2_y * x2_grid[i, j] + coeff_x3_y * x3_grid[i, j] <= ingredient_y_max and
            coeff_x2_kt * x2_grid[i, j] + coeff_x3_kt * x3_grid[i, j] <= kitchen_time_max):
            # If all constraints are satisfied, calculate the revenue
            feasibility[i, j] = -22 * 0 + -6 * x2_grid[i, j] + -2 * x3_grid[i, j]  # x1 is fixed at 0
        else:
            # Mark infeasible points with NaN
            feasibility[i, j] = np.nan

# Plot the feasible region with a color map
plt.figure(figsize=(8, 6))
cp = plt.contourf(x2_grid, x3_grid, feasibility, cmap="viridis", levels=np.linspace(np.nanmin(feasibility), np.nanmax(feasibility), 100))
plt.colorbar(cp, label="Projected Revenue")

# Set plot labels and title
plt.xlabel("Quantity of Dish B (x2)")
plt.ylabel("Quantity of Dish C (x3)")
plt.title("Feasible Region with x1 = 0 (No Dish A)")

# Display the plot
plt.show()

