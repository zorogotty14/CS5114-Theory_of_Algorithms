# Re-evaluating the feasible regions with x2=0 and x3=0 separately
# We need to re-calculate the maximum ranges for x1 when x2=0 and x3=0
# For x2=0
x1_range_x2_zero = np.linspace(0, b[0] / A[0, 0], resolution)  # based on Ingredient X constraint
x3_range_x2_zero = np.linspace(0, b[2] / A[2, 2], resolution)  # based on Kitchen Time constraint
x1_grid_x2_zero, x3_grid_x2_zero = np.meshgrid(x1_range_x2_zero, x3_range_x2_zero)

# Check feasibility for x2=0
feasibility_x2_zero = (A[1, 0] * x1_grid_x2_zero + A[1, 2] * x3_grid_x2_zero <= b[1])

# For x3=0
x1_range_x3_zero = np.linspace(0, b[0] / A[0, 0], resolution)  # based on Ingredient X constraint
x2_range_x3_zero = np.linspace(0, b[1] / A[1, 1], resolution)  # based on Ingredient Y constraint
x1_grid_x3_zero, x2_grid_x3_zero = np.meshgrid(x1_range_x3_zero, x2_range_x3_zero)

# Check feasibility for x3=0
feasibility_x3_zero = (A[2, 0] * x1_grid_x3_zero + A[2, 1] * x2_grid_x3_zero <= b[2])

# Visualize the feasible regions when x2=0 and x3=0
plt.figure(figsize=(12, 5))

# Plot for x2=0
plt.subplot(1, 2, 1)
plt.contourf(x1_grid_x2_zero, x3_grid_x2_zero, feasibility_x2_zero, cmap="viridis")
plt.xlabel("Quantity of Dish A (x1)")
plt.ylabel("Quantity of Dish C (x3)")
plt.title("Feasible Region with x2 = 0")
plt.colorbar()

# Plot for x3=0
plt.subplot(1, 2, 2)
plt.contourf(x1_grid_x3_zero, x2_grid_x3_zero, feasibility_x3_zero, cmap="viridis")
plt.xlabel("Quantity of Dish A (x1)")
plt.ylabel("Quantity of Dish B (x2)")
plt.title("Feasible Region with x3 = 0")
plt.colorbar()

plt.tight_layout()
plt.show()

