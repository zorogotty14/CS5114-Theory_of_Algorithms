import numpy as np
from scipy.optimize import linprog

# Objective coefficients (revenue per unit)
c = np.array([-22, -6, -2])  # Negative since linprog minimizes by default

# Coefficients of the constraints (left-hand side matrix)
A = np.array([
    [10, 2, 1],  # Ingredient X constraint
    [7, 3, 2],   # Ingredient Y constraint
    [2, 4, 1]    # Kitchen time constraint
])

# Right-hand side of the constraints
b = np.array([100, 72, 80])

# Solve the linear programming problem
result = linprog(c, A_ub=A, b_ub=b, method='highs')

# Print the optimal solution
if result.success:
    print("Optimal solution:")
    for i, var in enumerate(['Dish A', 'Dish B', 'Dish C']):
        print(f"{var}: {result.x[i]:.2f} units")
    print("Maximum revenue: $", round(-result.fun, 2))
else:
    print("Optimization was not successful. Error:", result.message)