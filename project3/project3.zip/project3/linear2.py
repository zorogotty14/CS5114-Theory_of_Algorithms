import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import linprog

# Objective coefficients (revenue per unit)
c = np.array([-22, -6, -2])  # Negative since linprog minimizes by default

# Coefficients of the constraints (left-hand side matrix)
A = np.array([
    [10, 2, 1],  # Ingredient X constraint
    [7, 3, 2],   # Ingredient Y constraint
    [2, 4, 1]    # Kitchen time constraint
])

# Right-hand side of the constraints
b = np.array([100, 72, 80])

# Bounds for decision variables (non-negativity constraint)
x_bounds = [(0, None), (0, None), (0, None)]

# Solve the linear programming problem
result = linprog(c, A_ub=A, b_ub=b, bounds=x_bounds, method='highs')

# Print the optimal solution
print("Optimal solution:")
for i, var in enumerate(['Dish A', 'Dish B', 'Dish C']):
    print(f"{var}: {round(result.x[i], 2)} servings")

# Calculate and print the maximum revenue
max_revenue = -result.fun  # Negate since linprog minimizes by default
print("Maximum revenue: $", round(max_revenue, 2))

# Plot the optimal solution as bar plots
dishes = ['Dish A', 'Dish B', 'Dish C']
quantities = result.x

plt.figure(figsize=(10, 6))
plt.bar(dishes, quantities, color=['red', 'green', 'blue'])
plt.xlabel('Dishes')
plt.ylabel('Quantity to Prepare')
plt.title('Optimal Dish Preparation for Maximized Revenue')
plt.show()
