import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import linprog

# Objective coefficients (revenue per unit)
c = np.array([-22, -6, -2])  # Negative since linprog minimizes by default

# Coefficients of the constraints (left-hand side matrix)
A = np.array([
    [10, 2, 1],  # Ingredient X constraint
    [7, 3, 2],   # Ingredient Y constraint
    [2, 4, 1]    # Kitchen time constraint
])

# Right-hand side of the constraints
b = np.array([100, 72, 80])

# Define constraint names and ranges
constraint_names = ['Ingredient X', 'Ingredient Y', 'Kitchen Time']
constraint_ranges = [(50, 150), (50, 100), (50, 100)]

# Varying constraint values within the ranges
num_points = 50
constraint_values = [np.linspace(start, end, num_points) for start, end in constraint_ranges]

# Initialize plots
fig, axs = plt.subplots(1, 3, figsize=(15, 5))

# Solve LP problem and plot for each constraint
for i, (name, values) in enumerate(zip(constraint_names, constraint_values)):
    objective_values = []
    for value in values:
        # Update constraint
        b_new = b.copy()
        b_new[i] = value
        
        # Solve LP problem
        result = linprog(c, A_ub=A, b_ub=b_new, bounds=[(0, None)]*3, method='highs')
        if result.success:
            objective_values.append(-result.fun)  # Negate since linprog minimizes
        else:
            objective_values.append(None)  # In case of optimization failure

    # Plot objective value vs. constraint value
    axs[i].plot(values, objective_values, marker='o')
    axs[i].set_xlabel(name + ' Available')
    axs[i].set_ylabel('Maximum Revenue ($)')
    axs[i].set_title('Effect of Varying ' + name)

plt.tight_layout()
plt.show()
