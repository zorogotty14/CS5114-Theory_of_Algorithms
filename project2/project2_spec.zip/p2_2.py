import matplotlib.pyplot as plt

# Input sizes and running times
input_sizes = [8, 10, 13, 15]
brute_force_times = [0.035470008850097656, 44.71088480949402, 50.495997190475464, 70.69822382926941]
frequency_based_times = [0.0, 0.0, 0.001288890838623, 0.017000913619995]
length_based_times = [0.0, 0.0, 0.002013206481934, 0.017018556594849]

# Convert strings to floats
frequency_based_times = [float(time) for time in frequency_based_times]
length_based_times = [float(time) for time in length_based_times]

# Plotting graph
plt.figure(figsize=(10, 6))

# Plot Brute Force Running Times
plt.plot(input_sizes, brute_force_times, marker='o', linestyle='-', label='Brute Force')

# Plot Frequency-Based Running Times
plt.plot(input_sizes, frequency_based_times, marker='o', linestyle='-', label='Frequency-Based')

# Plot Length-Based Running Times
plt.plot(input_sizes, length_based_times, marker='o', linestyle='-', label='Length-Based')

plt.xlabel('Input Size')
plt.ylabel('Running Time (s)')
plt.title('Running Time vs. Input Size')
plt.legend()
plt.grid(True)
plt.show()