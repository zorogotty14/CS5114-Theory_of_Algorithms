import time
import random
import matplotlib.pyplot as plt
import heapq

class Node:
    def __init__(self, char=None, freq=0, left=None, right=None):
        self.char = char
        self.freq = freq
        self.left = left
        self.right = right
    
    def __lt__(self, other):
        return self.freq < other.freq

def generate_frequency_table(text):
    frequency_table = {}
    for char in text:
        if char in frequency_table:
            frequency_table[char] += 1
        else:
            frequency_table[char] = 1
    return frequency_table

def build_huffman_tree(frequency_table):
    heap = [Node(char, freq) for char, freq in frequency_table.items()]
    heapq.heapify(heap)
    
    while len(heap) > 1:
        left = heapq.heappop(heap)
        right = heapq.heappop(heap)
        merged_node = Node(freq=left.freq + right.freq, left=left, right=right)
        heapq.heappush(heap, merged_node)
    
    return heap[0]

def generate_codewords(node, current_code="", codewords={}):
    if node is None:
        return
    if node.char is not None:
        codewords[node.char] = current_code
        return
    generate_codewords(node.left, current_code + "0", codewords)
    generate_codewords(node.right, current_code + "1", codewords)

def compress_text(text, codewords):
    compressed_text = ""
    for char in text:
        compressed_text += codewords[char]
    return compressed_text

# Function to generate random text with given alphabet size and uneven distribution of characters
def generate_random_text_uneven(length):
    # Define character frequencies based on desired distribution
    character_frequencies = {'a': 10, 'b': 5, 'c': 3, 'd': 2, 'e': 1}
    text = ''.join(random.choices(list(character_frequencies.keys()), weights=character_frequencies.values(), k=length))
    return text

# Function to generate random text with repetitive patterns
def generate_random_text_repetitive(length):
    # Define repetitive pattern
    pattern = "abcdef"
    repetitions = length // len(pattern)
    remainder = length % len(pattern)
    text = pattern * repetitions + pattern[:remainder]
    return text

# Function for frequency-based Huffman compression
def frequency_based_huffman_compression(text):
    frequency_table = generate_frequency_table(text)
    huffman_tree = build_huffman_tree(frequency_table)  # Use build_huffman_tree function
    codewords = {}
    generate_codewords(huffman_tree, "", codewords)
    return compress_text(text, codewords)

def build_huffman_tree_by_length(frequency_table):
    sorted_characters = sorted(frequency_table.items(), key=lambda x: len(x[1]))  
    # Sort characters by codeword length
    nodes = [Node(char=char, freq=freq) for char, freq in sorted_characters]  
    # Create nodes for each character
    while len(nodes) > 1:
        # Combine the two nodes with the lowest codeword lengths
        left = nodes.pop(0)
        right = nodes.pop(0)
        merged_node = Node(freq=left.freq + right.freq, left=left, right=right)
        nodes.append(merged_node)
        nodes.sort(key=lambda x: x.freq)  # Sort nodes by frequency
    return nodes[0]  # Return the root of the Huffman tree


def length_based_huffman_compression(text):
    frequency_table = generate_frequency_table(text)
    huffman_tree = build_huffman_tree_by_length(frequency_table)  # Use build_huffman_tree function
    codewords = {}
    generate_codewords(huffman_tree, "", codewords)
    return compress_text(text, codewords)

# Function to measure running time
def measure_running_time(algorithm, text):
    start_time = time.time()
    compressed_text = algorithm(text)
    end_time = time.time()
    return end_time - start_time

# Function to run experiments
def run_experiments(algorithm, text_characteristics, text_sizes):
    results = []

    for text_characteristic in text_characteristics:
        for text_size in text_sizes:
            if text_characteristic == 'Uneven Distribution':
                text = generate_random_text_uneven(text_size)
            elif text_characteristic == 'Repetitive Patterns':
                text = generate_random_text_repetitive(text_size)
            else:
                raise ValueError("Unknown text characteristic")
            
            start_time = time.time()
            compressed_text = algorithm(text)
            end_time = time.time()
            optimality = len(compressed_text) / len(text)
            complexity = end_time - start_time
            running_time = end_time - start_time
            results.append((text_characteristic, text_size, optimality, complexity, running_time))
    
    return results

# Define text characteristics and text sizes to experiment with
text_characteristics = ['Uneven Distribution', 'Repetitive Patterns']  # Example text characteristics
text_sizes = [1000, 2000, 3000]  # Example text sizes

# Run experiments for frequency-based Huffman compression
freq_results = run_experiments(frequency_based_huffman_compression, text_characteristics, text_sizes)

# Run experiments for length-based Huffman compression
length_results = run_experiments(length_based_huffman_compression, text_characteristics, text_sizes)

# Plotting graphs
plt.figure(figsize=(15, 5))

# Achieved optimality
plt.subplot(1, 3, 1)
for text_characteristic in text_characteristics:
    freq_data = [res[2] for res in freq_results if res[0] == text_characteristic]
    length_data = [res[2] for res in length_results if res[0] == text_characteristic]
    plt.plot(text_sizes, freq_data

, label=f'Freq, Characteristic: {text_characteristic}', marker='o')
    plt.plot(text_sizes, length_data, label=f'Length, Characteristic: {text_characteristic}', marker='x')

plt.xlabel('Text Size')
plt.ylabel('Achieved Optimality')
plt.title('Achieved Optimality')
plt.legend()

# Asymptotic complexity
plt.subplot(1, 3, 2)
for text_characteristic in text_characteristics:
    freq_data = [res[3] for res in freq_results if res[0] == text_characteristic]
    length_data = [res[3] for res in length_results if res[0] == text_characteristic]
    plt.plot(text_sizes, freq_data, label=f'Freq, Characteristic: {text_characteristic}', marker='o')
    plt.plot(text_sizes, length_data, label=f'Length, Characteristic: {text_characteristic}', marker='x')

plt.xlabel('Text Size')
plt.ylabel('Asymptotic Complexity')
plt.title('Asymptotic Complexity')
plt.legend()

# Simulation running time
plt.subplot(1, 3, 3)
for text_characteristic in text_characteristics:
    freq_data = [res[4] for res in freq_results if res[0] == text_characteristic]
    length_data = [res[4] for res in length_results if res[0] == text_characteristic]
    plt.plot(text_sizes, freq_data, label=f'Freq, Characteristic: {text_characteristic}', marker='o')
    plt.plot(text_sizes, length_data, label=f'Length, Characteristic: {text_characteristic}', marker='x')

plt.xlabel('Text Size')
plt.ylabel('Simulation Running Time')
plt.title('Simulation Running Time')
plt.legend()

plt.tight_layout()
plt.show()
