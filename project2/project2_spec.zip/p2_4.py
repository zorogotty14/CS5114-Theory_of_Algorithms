import matplotlib.pyplot as plt
from math import factorial, log

# Input sizes and running times
input_sizes = [2,4,5,6,7,8]

# Asymptotic complexities
brute_force_complexities = [size * factorial(size) for size in input_sizes]
frequency_based_complexities = [size * log(size) for size in input_sizes]
length_based_complexities = [size * log(size) for size in input_sizes]

# Plotting graph
plt.figure(figsize=(10, 6))

# Plot Brute Force Asymptotic Complexities
plt.plot(input_sizes, brute_force_complexities, marker='o', linestyle='-', label='Brute Force')

# Plot Frequency-Based Asymptotic Complexities
plt.plot(input_sizes, frequency_based_complexities, marker='o', linestyle='-', label='Frequency-Based')

# Plot Length-Based Asymptotic Complexities
plt.plot(input_sizes, length_based_complexities, marker='o', linestyle='-', label='Length-Based')

plt.xlabel('Input Size')
plt.ylabel('Asymptotic Complexity')
plt.title('Asymptotic Complexity vs. Input Size')
plt.legend()
plt.grid(True)
plt.show()