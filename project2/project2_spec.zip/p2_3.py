import matplotlib.pyplot as plt

# Data
sizes = [2, 4, 7, 11, 15, 19]
brute_force_ratios = [8.0, 8.0, 8.0, 8.0, 8.0, 8.0]
frequency_based_ratios = [8.0, 8.0, 5.090909090909091, 5.176470588235294, 2.608695652173913, 2.7142857142857144]
length_based_ratios = [8.0, 8.0, 5.090909090909091, 5.176470588235294, 2.608695652173913, 2.7142857142857144]

# Plotting
plt.figure(figsize=(10, 6))

plt.plot(sizes, brute_force_ratios, marker='o', linestyle='-', label='Brute Force')
plt.plot(sizes, frequency_based_ratios, marker='o', linestyle='-', label='Frequency Based Huffman')
plt.plot(sizes, length_based_ratios, marker='o', linestyle='-', label='Length Based Huffman')

plt.xlabel('Size of String')
plt.ylabel('Compression Ratio')
plt.title('Compression Ratio vs. Size of String')
plt.legend()
plt.grid(True)
plt.show()