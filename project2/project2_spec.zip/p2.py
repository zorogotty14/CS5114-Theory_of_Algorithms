import itertools
import heapq
import time
import random
import string

class Node:
    def __init__(self, char=None, freq=0, left=None, right=None):
        self.char = char
        self.freq = freq
        self.left = left
        self.right = right
    
    def __lt__(self, other):
        return self.freq < other.freq

def generate_frequency_table(text):
    frequency_table = {}
    for char in text:
        if char in frequency_table:
            frequency_table[char] += 1
        else:
            frequency_table[char] = 1
    return frequency_table

def build_huffman_tree(frequency_table):
    heap = [Node(char, freq) for char, freq in frequency_table.items()]
    heapq.heapify(heap)
    
    while len(heap) > 1:
        left = heapq.heappop(heap)
        right = heapq.heappop(heap)
        merged_node = Node(freq=left.freq + right.freq, left=left, right=right)
        heapq.heappush(heap, merged_node)
    
    return heap[0]

def generate_codewords(node, current_code="", codewords={}):
    if node is None:
        return
    if node.char is not None:
        codewords[node.char] = current_code
        return
    generate_codewords(node.left, current_code + "0", codewords)
    generate_codewords(node.right, current_code + "1", codewords)

def compress_text(text, codewords):
    compressed_text = ""
    for char in text:
        compressed_text += codewords[char]
    return compressed_text

def build_huffman_tree_by_length(frequency_table):
    sorted_characters = sorted(frequency_table.items(), key=lambda x: len(x[1]))  
    # Sort characters by codeword length
    nodes = [Node(char=char, freq=freq) for char, freq in sorted_characters]  
    # Create nodes for each character
    while len(nodes) > 1:
        # Combine the two nodes with the lowest codeword lengths
        left = nodes.pop(0)
        right = nodes.pop(0)
        merged_node = Node(freq=left.freq + right.freq, left=left, right=right)
        nodes.append(merged_node)
        nodes.sort(key=lambda x: x.freq)  # Sort nodes by frequency
    return nodes[0]  # Return the root of the Huffman tree

def brute_force_huffman_compression(text):
    frequency_table = generate_frequency_table(text)
    all_codewords = list(itertools.permutations(frequency_table.keys()))
    min_bits = float('inf')
    optimal_codewords = None
    
    for codewords in all_codewords:
        current_codewords = {char: code for char, code in zip(frequency_table.keys(), codewords)}
        compressed_text = compress_text(text, current_codewords)
        bits = len(compressed_text)
        if bits < min_bits:
            min_bits = bits
            optimal_codewords = current_codewords
            
    return compress_text(text, optimal_codewords)

def frequency_based_huffman_compression(text):
    frequency_table = generate_frequency_table(text)
    huffman_tree = build_huffman_tree(frequency_table)  # Use build_huffman_tree function
    codewords = {}
    generate_codewords(huffman_tree, "", codewords)
    return compress_text(text, codewords)

def length_based_huffman_compression(text):
    frequency_table = generate_frequency_table(text)
    huffman_tree = build_huffman_tree_by_length(frequency_table)  # Use build_huffman_tree function
    codewords = {}
    generate_codewords(huffman_tree, "", codewords)
    return compress_text(text, codewords)

# Generate a random text file with words ranging from 10 to 100
def generate_random_text(length):
    word_length = random.randint(1, 10)
    words = []
    while len(" ".join(words)) < length:
        word = ''.join(random.choices(string.ascii_lowercase, k=word_length))
        words.append(word)
        word_length = random.randint(1, 10)
    return " ".join(words)

# Measure running time for each algorithm
def measure_running_time(algorithm, text):
    start_time = time.time()
    compressed_text = algorithm(text)
    end_time = time.time()
    print("start time, end time, compressed_text")
    print(start_time, end_time, compressed_text)
    return end_time - start_time

def run_experiments(input_sizes):
    brute_force_times = []
    frequency_based_times = []
    length_based_times = []

    for size in input_sizes:
        text = generate_random_text(size)
        print(text)
        brute_force_time = measure_running_time(brute_force_huffman_compression, text)
        frequency_based_time = measure_running_time(frequency_based_huffman_compression, text)
        length_based_time = measure_running_time(length_based_huffman_compression, text)
        
        brute_force_times.append(brute_force_time)
        frequency_based_times.append(frequency_based_time)
        length_based_times.append(length_based_time)
    
    return input_sizes, brute_force_times, frequency_based_times, length_based_times

# if __name__ == "__main__":
#     input_sizes = [2,3,4,5,6,7,8]
#     input_sizes, brute_force_times, frequency_based_times, length_based_times = run_experiments(input_sizes)
    
#     print("Input Sizes:", input_sizes)
#     print("Brute Force Running Times:", ["{:.15f}".format(time) for time in brute_force_times])
#     print("Frequency Based Running Times:", ["{:.15f}".format(time) for time in frequency_based_times])
#     print("Length Based Running Times:", ["{:.15f}".format(time) for time in length_based_times])

def calculate_compression_ratio(original_text, compressed_text):
    original_size = len(original_text) * 8  # Size of original text in bits (assuming ASCII encoding)
    compressed_size = len(compressed_text)  # Size of compressed text in bits
    compression_ratio = original_size / compressed_size
    return compression_ratio

# Example usage:
original_text = "iapdn aodjp lao ada"

brute_force_compressed_text = brute_force_huffman_compression(original_text)
frequency_based_compressed_text = frequency_based_huffman_compression(original_text)
length_based_compressed_text = length_based_huffman_compression(original_text)

compression_ratio_brute_force = calculate_compression_ratio(original_text, brute_force_compressed_text)
compression_ratio_frequency_based = calculate_compression_ratio(original_text, frequency_based_compressed_text)
compression_ratio_length_based = calculate_compression_ratio(original_text, length_based_compressed_text)

print("size of string",len(original_text))
print("Compression Ratio (Brute Force):", compression_ratio_brute_force)
print("Compression Ratio (Frequency Based Huffman):", compression_ratio_frequency_based)
print("Compression Ratio (Length Based Huffman):", compression_ratio_length_based)
