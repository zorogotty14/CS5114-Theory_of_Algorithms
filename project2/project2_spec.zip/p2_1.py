import time
import random
import matplotlib.pyplot as plt
import heapq

# Function to generate random text
def generate_random_text(length):
    return ''.join(random.choices("abcdefghijklmnopqrstuvwxyz", k=length))

class Node:
    def __init__(self, char=None, freq=0, left=None, right=None):
        self.char = char
        self.freq = freq
        self.left = left
        self.right = right
    
    def __lt__(self, other):
        return self.freq < other.freq

def generate_frequency_table(text):
    frequency_table = {}
    for char in text:
        if char in frequency_table:
            frequency_table[char] += 1
        else:
            frequency_table[char] = 1
    return frequency_table

def build_huffman_tree(frequency_table):
    heap = [Node(char, freq) for char, freq in frequency_table.items()]
    heapq.heapify(heap)
    
    while len(heap) > 1:
        left = heapq.heappop(heap)
        right = heapq.heappop(heap)
        merged_node = Node(freq=left.freq + right.freq, left=left, right=right)
        heapq.heappush(heap, merged_node)
    
    return heap[0]

def generate_codewords(node, current_code="", codewords={}):
    if node is None:
        return
    if node.char is not None:
        codewords[node.char] = current_code
        return
    generate_codewords(node.left, current_code + "0", codewords)
    generate_codewords(node.right, current_code + "1", codewords)

def compress_text(text, codewords):
    compressed_text = ""
    for char in text:
        compressed_text += codewords[char]
    return compressed_text

# Function for frequency-based Huffman compression
def frequency_based_huffman_compression(text):
    frequency_table = generate_frequency_table(text)
    huffman_tree = build_huffman_tree(frequency_table)  # Use build_huffman_tree function
    codewords = {}
    generate_codewords(huffman_tree, "", codewords)
    return compress_text(text, codewords)


def build_huffman_tree_by_length(frequency_table):
    sorted_characters = sorted(frequency_table.items(), key=lambda x: len(x[1]))  
    # Sort characters by codeword length
    nodes = [Node(char=char, freq=freq) for char, freq in sorted_characters]  
    # Create nodes for each character
    while len(nodes) > 1:
        # Combine the two nodes with the lowest codeword lengths
        left = nodes.pop(0)
        right = nodes.pop(0)
        merged_node = Node(freq=left.freq + right.freq, left=left, right=right)
        nodes.append(merged_node)
        nodes.sort(key=lambda x: x.freq)  # Sort nodes by frequency
    return nodes[0]  # Return the root of the Huffman tree


def length_based_huffman_compression(text):
    frequency_table = generate_frequency_table(text)
    huffman_tree = build_huffman_tree_by_length(frequency_table)  # Use build_huffman_tree function
    codewords = {}
    generate_codewords(huffman_tree, "", codewords)
    return compress_text(text, codewords)

# Function to run experiments
def run_experiments(algorithm):
    input_sizes = [10000,15000, 20000, 25000, 30000]
    optimality = []
    complexity = []
    running_time = []

    for size in input_sizes:
        text = generate_random_text(size)
        start_time = time.time()
        compressed_text = algorithm(text)
        end_time = time.time()
        optimality.append(len(compressed_text) / len(text))
        complexity.append((end_time - start_time))
        running_time.append((end_time - start_time)) 
    
    return input_sizes, optimality, complexity, running_time

# Run experiments for frequency-based Huffman compression
freq_input_sizes, freq_optimality, freq_complexity, freq_running_time = run_experiments(frequency_based_huffman_compression)

# Run experiments for length-based Huffman compression
length_input_sizes, length_optimality, length_complexity, length_running_time = run_experiments(length_based_huffman_compression)

# Plotting graphs
plt.figure(figsize=(15, 5))

# Achieved optimality
plt.subplot(1, 3, 1)
plt.plot(freq_input_sizes, freq_optimality, label='Frequency-Based Huffman')
plt.plot(length_input_sizes, length_optimality, label='Length-Based Huffman')
plt.xlabel('Input Size')
plt.ylabel('Optimality')
plt.title('Achieved Optimality')
plt.legend()

# Asymptotic complexity
plt.subplot(1, 3, 2)
plt.plot(freq_input_sizes, freq_complexity, label='Frequency-Based Huffman')
plt.plot(length_input_sizes, length_complexity, label='Length-Based Huffman')
plt.xlabel('Input Size')
plt.ylabel('Asymptotic Complexity')
plt.title('Asymptotic Complexity')
plt.legend()

# Simulation running time
plt.subplot(1, 3, 3)
plt.plot(freq_input_sizes, freq_running_time, label='Frequency-Based Huffman')
plt.plot(length_input_sizes, length_running_time, label='Length-Based Huffman')
plt.xlabel('Input Size')
plt.ylabel('Running Time (s)')
plt.title('Simulation Running Time')
plt.legend()

plt.tight_layout()
plt.show()