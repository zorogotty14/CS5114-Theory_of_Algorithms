import itertools

def euclidean_distance(city1, city2):
    x1, y1 = city1
    x2, y2 = city2
    return ((x1 - x2) ** 2 + (y1 - y2) ** 2) ** 0.5

def total_distance(path, cities):
    distance = 0
    for i in range(len(path) - 1):
        distance += euclidean_distance(cities[path[i] - 1], cities[path[i+1] - 1])
    return distance

def parse_tsp_file(filename):
    cities = []
    with open(filename, 'r') as file:
        for line in file:
            if line.strip() == 'EOF':
                break
            city_info = line.split()
            city_id = int(city_info[0])
            x = float(city_info[1])
            y = float(city_info[2])
            cities.append((x, y))
    return cities

def naive_tsp(cities):
    num_cities = len(cities)
    min_distance = float('inf')
    optimal_path = None
    
    for permutation in itertools.permutations(range(1, num_cities + 1)):
        path = [0] + list(permutation)
        distance = total_distance(path, cities)
        if distance < min_distance:
            min_distance = distance
            optimal_path = path
    
    optimal_path.append(0)
    
    return optimal_path, min_distance

filename = 'usa115475.txt'
cities = parse_tsp_file(filename)

optimal_path, min_distance = naive_tsp(cities)
print("Optimal Path:", optimal_path)
print("Minimum Distance:", min_distance)

def tsp_top_down(cities):
    num_cities = len(cities)
    dp = np.full((1 << num_cities, num_cities), -1)
    def tsp_helper(mask, current_city):
        if mask == (1 << num_cities) - 1:  
            return euclidean_distance(cities[current_city], cities[0])
        if dp[mask][current_city] != -1:  
            return dp[mask][current_city]
        min_distance = float('inf')
        for next_city in range(num_cities):
            if mask & (1 << next_city) == 0: 
                distance = euclidean_distance(cities[current_city], cities[next_city]) + \
                           tsp_helper(mask | (1 << next_city), next_city)
                min_distance = min(min_distance, distance) 
        dp[mask][current_city] = min_distance
        return min_distance
    return tsp_helper(1, 0)

def tsp_bottom_up(cities):
    num_cities = len(cities)
    dp = np.full((1 << num_cities, num_cities), float('inf'))  
    for i in range(num_cities):
        dp[1 << i][i] = 0
    for mask in range(1, 1 << num_cities):
        for current_city in range(num_cities):
            if mask & (1 << current_city):  
                for next_city in range(num_cities):
                    if mask & (1 << next_city) == 0:  
                        distance = euclidean_distance(cities[current_city], cities[next_city]) + \
                                   dp[mask][current_city]
                        dp[mask | (1 << next_city)][next_city] = min(dp[mask | (1 << next_city)][next_city], distance)
    min_distance = float('inf')
    for i in range(num_cities):
        min_distance = min(min_distance, dp[(1 << num_cities) - 1][i] + euclidean_distance(cities[i], cities[0]))
    return min_distance


print("Minimum Distance using top down approach:", tsp_top_down(cities))
print("Minimum Distance using bottom-up approach:", tsp_bottom_up(cities))