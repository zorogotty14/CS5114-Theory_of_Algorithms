import numpy as np
import matplotlib.pyplot as plt

# Define the input sizes and execution times for each algorithm
input_sizes = [10, 20, 50, 100]
naive_execution_times = [0.0009968280792236328, 0.001993894577026367, 0.015955686569213867, 0.15579771995544434]
top_down_execution_times = [0.0009963512420654297, 0.0019941329956054688, 0.01595926284790039, 0.16279149055480957]
bottom_up_execution_times = [0.001994609832763672, 0.0039899349212646484, 0.012965202331542969, 0.09874320030212402]

# Plotting the results
plt.plot(input_sizes, naive_execution_times, label='Naive TSP')
plt.plot(input_sizes, top_down_execution_times, label='Top-Down DP TSP')
plt.plot(input_sizes, bottom_up_execution_times, label='Bottom-Up DP TSP')

plt.xlabel('Number of Cities')
plt.ylabel('Execution Time (seconds)')
plt.title('Sensitivity Analysis of TSP Algorithms')
plt.legend()
plt.grid(True)
plt.show()
