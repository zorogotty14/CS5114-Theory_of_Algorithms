import numpy as np
import matplotlib.pyplot as plt

# Define the input sizes and execution times for each algorithm
input_sizes = [10, 20, 50, 100, 200, 500, 1000]
naive_execution_times = [0.000997304916381836, 0.0019941329956054688, 0.015957117080688477, 0.15578889846801758, 1.2410080432891846, 33.64000058174133, 1404.4860360622406]
top_down_execution_times = [0.0019943714141845703, 0.001993894577026367, 0.01595473289489746, 0.16179132461547852, 1.320141077041626, 36.09803652763367, 1436.9358761310577]
bottom_up_execution_times = [0.0019943714141845703, 0.003988981246948242, 0.012965679168701172, 0.09973931312561035, 0.7122483253479004, 14.575973272323608, 553.153938293457]

# Plotting the results
plt.plot(input_sizes, naive_execution_times, label='Naive TSP')
plt.plot(input_sizes, top_down_execution_times, label='Top-Down DP TSP')
plt.plot(input_sizes, bottom_up_execution_times, label='Bottom-Up DP TSP')

plt.xlabel('Number of Cities')
plt.ylabel('Execution Time (seconds)')
plt.title('Sensitivity Analysis of TSP Algorithms')
plt.legend()
plt.grid(True)
plt.show()