import numpy as np
import matplotlib.pyplot as plt

# Input sizes
n_values = [100, 500, 1000]

# Approximate time complexities for top-down and bottom-up approaches
time_top_down_values = [2**n * n**2 for n in n_values]
time_bottom_up_values = [2**n * n**2 for n in n_values]

# Plotting the results
plt.plot(n_values, time_top_down_values, label='Top-Down DP TSP (Approximate)')
plt.plot(n_values, time_bottom_up_values, label='Bottom-Up DP TSP (Approximate)')

plt.xlabel('Input Size (Number of Cities, n)')
plt.ylabel('Time Complexity')
plt.title('Approximate Time Complexity of TSP Algorithms')
plt.legend()
plt.grid(True)
plt.yscale('log')  # Set y-axis scale to logarithmic
plt.show()