Change the path of the dataset in naive.py 
and run it as follows: 
python naive.py, it will take long time to execute 
other files are also same way to run 

